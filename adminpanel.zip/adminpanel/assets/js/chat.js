
function GetChatHistory(receiver_id){
				$.ajax({
						  //dataType : "json",
  						  url: 'get-chat-history-vendor?receiver_id='+receiver_id,
						  success:function(data)
						  {
  							$('#dumppy').html(data);
							//ScrollDown();	 
						  },
						  error: function (jqXHR, status, err) {
 							 // alert('Local error callback');
						  }
 					});
}