<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-tachometer" aria-hidden="true"></i> Dashboard
        <small>Control panel</small>
      </h1>
    </section>
     <?php           
            if($role != ROLE_ADMIN && $role != ROLE_MANAGER)
            {
            ?>
    <section class="content">
        <h1>Welcome to Your Dashboard....</h1>
    </section>
<?php }?>

<?php           
            if($role == ROLE_ADMIN)
            {
            ?>
            <section class="content">
        <h1>Welcome to Admin Panel....</h1>
    </section>
<?php }?>
</div>